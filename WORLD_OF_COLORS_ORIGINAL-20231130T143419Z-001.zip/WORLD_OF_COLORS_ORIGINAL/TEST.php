<?php include('conexion.php') ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>World_Of_Colors</title>
    <link rel="stylesheet" href="css/Css_De_TEST.css">
</head>
<body>
    <div id="container">  
        <header>
            <img id="Fondo_Encabezado" src="imagenes/fondo del encabezado.png">
        
            <div>
                <a href="index.html"><button class="Inicio" title="Inicio">INICIO</button></a>
            </div>
            <div>
                <img class="zoom-acercar" id="zoomacercar" title="Aumentar El Tamaño Del Texto" src="imagenes/acercar.png">
            </div>
            <div>
                <img class="zoom-alejar" id="zoomalejar" title="Reducir El Tamaño Del Texto" src="imagenes/Alejar.png" >
            </div>
        </header>

        <div>
            <img class="imagen_TEST" src="imagenes/imagen_TEST.jpg"> 
        </div>

   
        <div class="formulario">
            <div class="encabezado_formulario">
                <h1>BIENVENIDO</h1>
                <p>°Llene el siguiente formulario para realizar el test:</p>
            </div>
            <form action="" method="post">
                <div class="username">
                    <input oninvalid="this.setCustomValidity('NOMBRE DEL PACIENTE')" 
                    oninput="this.setCustomValidity('')" type="text" name="nombre" required>
                    <label>Nombre Del Paciente</label>
                </div>
                <div class="username">
                    <input title="DE 8 A 10 DIGITOS" type="text" name="id" pattern="\d{8,10}" 
                    oninvalid="this.setCustomValidity('DOCUMENTO ID/CC')" 
                    oninput="this.setCustomValidity('')" required>
                    <label>Documento</label>
                </div>
                <div>
                <?php
if (!empty($mensaje_error)) {
    echo '<p style="
     position:absolute;
     top: 75%;
     left: 40%;
     transform: translate(-50%, -50%);
      color: red;
      z-index: 999;
       text-shadow: 0.1vw 0.1vw 0.2vw rgba(0, 0, 0, 10);
       font-size: 1.5vw;
      ">' . $mensaje_error . '</p>';
}
?>
   
               </div>
     
                <div class="inciarTest">
                    <input type="submit" value="Iniciar Test">
                </div>
            </form>
        </div>
    </div>
  
    <script src="JavaScript/Java_Test.js"></script>
   
</body>
</html>
