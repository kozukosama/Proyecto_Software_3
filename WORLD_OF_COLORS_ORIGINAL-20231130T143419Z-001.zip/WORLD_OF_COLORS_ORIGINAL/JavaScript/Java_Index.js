const zoomacercar = document.getElementById('zoomacercar');
const zoomalejar = document.getElementById('zoomalejar');

let zoomactual = 150;
const zoomMaximo =190;
const zoomMinimo = 80;

zoomacercar.addEventListener('click', () => {
    zoomactual += 2;
    if (zoomactual > zoomMaximo) {
        zoomactual = zoomMaximo;
    }
    zoomdepagina(zoomactual);
});

zoomalejar.addEventListener('click', () => {
    zoomactual -= 2;
    if (zoomactual < zoomMinimo) {
        zoomactual = zoomMinimo;
    }
    zoomdepagina(zoomactual);
});

function zoomdepagina(zoomactual) {
    
    const elementosDeTexto = document.querySelectorAll('#seccion1 p, #seccion1 h1, #seccion1 h2, #seccion2 h1, #seccion2 p');

    elementosDeTexto.forEach(elemento => {
        elemento.style.fontSize = zoomactual + "%";
    });

}


  