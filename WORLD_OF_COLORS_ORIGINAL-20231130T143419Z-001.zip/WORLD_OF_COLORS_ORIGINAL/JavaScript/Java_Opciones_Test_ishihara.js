console.log(nombreEnJavaScript);
var resultado = 0;
let imagenActual = 0;
let intentosRealizados = 0;
let contadorimg = 0;
const limiteIntentos = 3;


function seleccionarOpcion(valor) {
   

        if (valor == 1) {
            resultado += 1;
            contadorimg++;
            console.log(resultado);
     
        } else if (valor == 0) {
            resultado +=  0;
            contadorimg++;
            console.log(resultado);
        
        } else if (valor == -1) {
            resultado += -1;
            contadorimg++;
            console.log(resultado);
        }
   
    if (intentosRealizados >= limiteIntentos) {
        final() 
   
    }
 
    intentosRealizados++;
    cambiarOpciones();
    cambiarImagen();
    

}


function cambiarImagen() {
    let imagen = document.querySelector('.imagen_TEST');
  
    const imagenes = ['imagenes_Test/ishihara-image-19.jpg',
                      'imagenes_Test/ishihara-image-20.jpg',
                       'imagenes_Test/ishihara-image-21.jpg'];

    imagen.src = imagenes[imagenActual];
    imagenActual++;
    
}

function final() {
    let opcionesContainer = document.getElementById('cuadrofinal');
   
    let nuevasOpcionesHTML = "";
    let resultadoTexto = "";
    if (resultado >= 2)
    {
        resultadoTexto = "DEUTERANOPIA";
      
        nuevasOpcionesHTML = `
          <div>
               <div class="alargar">
                <h1 class="titulo_final"> Sñr@ ${nombreEnJavaScript} su diagnostico es: <span class="resaltado">DEUTERANOPÍA</span><br>
                 Haz click en la imágen para ver más información: </h1>
            </div>
            <div>
                <a href="deuteranopia.html"><img class="imagen_final" src="imagenes_finales/DEUTERANOPIA.png"> </a>
            </div>
        </div>
        
        `;
    } if (resultado <= -2)
    {
        resultadoTexto = "PROTANOPIA";
     
        nuevasOpcionesHTML = `
        <div>
             <div class="alargar">
              <h1 class="titulo_final"> Sñr@ ${nombreEnJavaScript}  su diagnostico es: <span class="resaltado">PROTANOPÍA</span><br>
               Haz click en la imágen para ver más información: </h1>
          </div>
          <div>
              <a href="protanopia.html"><img class="imagen_final" src="imagenes_finales/PROTANOPIA.png"> </a>
          </div>
      </div>
      
      `;
    }
    else if (resultado == 0){
        resultadoTexto = "NO TIENES DALTONISMO";
        nuevasOpcionesHTML = `
        <div>
             <div class="alargar">
              <h1 class="titulo_final_1"> Sñr@ ${nombreEnJavaScript}  su diagnostico es: NO TIENES <span class="resaltado">DALTONISMO</span><br>
               <span class="pequeno">Haz click en la imágen para ver más información acerca del Daltonismo!!</span> </h1>
          </div>
          <div>
              <a href="Tipos_De_Daltonismo.html"><img class="imagen_final_1" src="imagenes_finales/NORMAL.jpg"> </a>
          </div>
      </div>
      
      `; 
    }
    opcionesContainer.innerHTML = nuevasOpcionesHTML;

    let xhr = new XMLHttpRequest();
    xhr.open("POST", "conexion.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Aquí puedes realizar acciones adicionales después de enviar los datos al servidor
            console.log("Resultado enviado correctamente");
        }
    };
    xhr.send("resultadoTexto=" + encodeURIComponent(resultadoTexto));


}

function cambiarOpciones() {
    let opcionesContainer = document.getElementById('opcionesContainer');
    let nuevasOpcionesHTML = "";
   
    if (contadorimg > 0) {
        nuevasOpcionesHTML = `
        <div id="opciondeuteranomalia" onclick="seleccionarOpcion(1)"> 4 </div>
        <div id="opcionprotanomalia" onclick="seleccionarOpcion(-1)"> 2 </div>
        <div id="opcionNormal" onclick="seleccionarOpcion(0)"> 42 </div>
      
        `;
    }  if (contadorimg > 1){
        nuevasOpcionesHTML = `
        <div id="opcionNormal" onclick="seleccionarOpcion(0)"> 35 </div>
        <div id="opciondeuteranomalia" onclick="seleccionarOpcion(1)"> 3 </div>
        <div id="opcionprotanomalia" onclick="seleccionarOpcion(-1)"> 5 </div>
        `;
    }if (contadorimg > 2) {
        nuevasOpcionesHTML = `
        <div id="opciondeuteranomalia" onclick="seleccionarOpcion(1)"> 9 </div>
        <div id="opcionNormal" onclick="seleccionarOpcion(0)"> 96 </div>
        <div id="opcionprotanomalia" onclick="seleccionarOpcion(-1)"> 6 </div>
        `;
    }
    opcionesContainer.innerHTML = nuevasOpcionesHTML;
}

document.addEventListener("DOMContentLoaded", function () {
    const zoomacercar = document.getElementById('zoomacercar');
    const zoomalejar = document.getElementById('zoomalejar');

    let zoomactual = 50;
    const zoomMaximo = 64;
    const zoomMinimo = 30;

    const tamanosIniciales = {
        h2: parseFloat(window.getComputedStyle(document.querySelector('h2')).fontSize),
        h1: parseFloat(window.getComputedStyle(document.querySelector('h1')).fontSize),
        div: parseFloat(window.getComputedStyle(document.querySelector('.opciones div')).fontSize),
    };

    zoomacercar.addEventListener('click', () => {
        zoomactual += 5;
        if (zoomactual > zoomMaximo) {
            zoomactual = zoomMaximo;
        }
        zoomdepagina(zoomactual);
    });

    zoomalejar.addEventListener('click', () => {
        zoomactual -= 5;
        if (zoomactual < zoomMinimo) {
            zoomactual = zoomMinimo;
        }
        zoomdepagina(zoomactual);
    });

    function zoomdepagina(zoomactual) {
        const elementosDeTexto = document.querySelectorAll('.alargar h1');

        elementosDeTexto.forEach(elemento => {
            const tipoElemento = elemento.tagName.toLowerCase();
            const tamañoBase = tamanosIniciales[tipoElemento];
            const tamañoZoom = tamañoBase * (zoomactual / 100);
            elemento.style.fontSize = tamañoZoom + "px";
        });
    }
});





