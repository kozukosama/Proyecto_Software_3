const zoomacercar = document.getElementById('zoomacercar1');
const zoomalejar = document.getElementById('zoomalejar1');

let zoomactual = 380;
const zoomMaximo =520;
const zoomMinimo = 180;

zoomacercar.addEventListener('click', () => {
    zoomactual += 7;
    if (zoomactual > zoomMaximo) {
        zoomactual = zoomMaximo;
    }
    zoomdepagina(zoomactual);
});

zoomalejar.addEventListener('click', () => {
    zoomactual -= 7;
    if (zoomactual < zoomMinimo) {
        zoomactual = zoomMinimo;
    }
    zoomdepagina(zoomactual);
});

function zoomdepagina(zoomactual) {
    
    const elementosDeTexto = document.querySelectorAll('p');

    elementosDeTexto.forEach(elemento => {
        elemento.style.fontSize = zoomactual + "%";
    });

}



function redirigirPagina(opcionSeleccionada) {
    var urls = {
      'protanopia': 'protanopia.html',
      'tritanopia': 'tritanopia.html',
      'deuteranopia': 'deuteranopia.html',
      'acromatico' : 'acromatico.html',
      'protanomalia' : 'protanomalia.html',
      'tritanomalia' : 'tritanomalia.html',
      'deuteranomalia' : 'deuteranomalia.html'
    };
  

    var urlRedireccion = urls[opcionSeleccionada];
  

    if (urlRedireccion) {
      window.location.href = urlRedireccion;
    }
  }
