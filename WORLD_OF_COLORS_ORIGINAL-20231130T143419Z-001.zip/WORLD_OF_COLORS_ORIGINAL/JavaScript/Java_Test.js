const zoomacercar = document.getElementById('zoomacercar');
const zoomalejar = document.getElementById('zoomalejar');

let zoomactual = 100;
const zoomMaximo = 120;
const zoomMinimo = 80;

const tamanosIniciales = {
    p: parseFloat(window.getComputedStyle(document.querySelector('p')).fontSize),
    h1: parseFloat(window.getComputedStyle(document.querySelector('h1')).fontSize)
};

zoomacercar.addEventListener('click', () => {
    zoomactual += 2;
    if (zoomactual > zoomMaximo) {
        zoomactual = zoomMaximo;
    }
    zoomdepagina(zoomactual);
});

zoomalejar.addEventListener('click', () => {
    zoomactual -= 2;
    if (zoomactual < zoomMinimo) {
        zoomactual = zoomMinimo;
    }
    zoomdepagina(zoomactual);
});

function zoomdepagina(zoomactual) {
    const elementosDeTexto = document.querySelectorAll('p, h1');

    elementosDeTexto.forEach(elemento => {
        const tipoElemento = elemento.tagName.toLowerCase();
        const tamañoBase = tamanosIniciales[tipoElemento];
        const tamañoZoom = tamañoBase * (zoomactual / 100);
        elemento.style.fontSize = tamañoZoom + "px";
    });
}
