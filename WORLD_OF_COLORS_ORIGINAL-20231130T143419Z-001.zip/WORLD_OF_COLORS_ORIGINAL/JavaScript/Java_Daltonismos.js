const zoomacercar = document.getElementById('zoomacercar1');
const zoomalejar = document.getElementById('zoomalejar1');

let zoomactual = 220;
const zoomMaximo =250;
const zoomMinimo = 180;



zoomacercar.addEventListener('click', () => {
    zoomactual += 7;
    if (zoomactual > zoomMaximo) {
        zoomactual = zoomMaximo;
    }
    zoomdepagina(zoomactual);
});

zoomalejar.addEventListener('click', () => {
    zoomactual -= 7;
    if (zoomactual < zoomMinimo) {
        zoomactual = zoomMinimo;
    }
    zoomdepagina(zoomactual);
});

function zoomdepagina(zoomactual) {
    
    const elementosDeTexto = document.querySelectorAll('h1, p, h2, h3');

    elementosDeTexto.forEach(elemento => {
        elemento.style.fontSize = zoomactual + "%";
    });

}

function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}


document.getElementById('daltonimo_cuadro').style.backgroundColor = getRandomColor();

const coloresEspecificos = [
    '#352929', 
    '#554141',  
    '#6A5555'  
];
const colorSeleccionado = coloresEspecificos[Math.floor(Math.random() * coloresEspecificos.length)];

document.body.style.backgroundColor = colorSeleccionado;


