<?php include('conexion.php') ?>
<?php
session_start();
$nombre = isset($_SESSION['nombre']) ? $_SESSION['nombre'] : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>World_Of_Colors</title>
    <link rel="stylesheet" href="css/Css_De_TEST_ishihara.css">
</head>
<body>
    <div id="container">  
        <header>
            <img id="Fondo_Encabezado" src="imagenes/fondo del encabezado.png">
        
            <div>
                <a href="index.html"><button class="Inicio" title="Inicio">INICIO</button></a>
            </div>
            <div>
                <img class="zoom-acercar" id="zoomacercar" title="Aumentar El Tamaño Del Texto" src="imagenes/acercar.png">
            </div>
            <div>
                <img class="zoom-alejar" id="zoomalejar" title="Reducir El Tamaño Del Texto" src="imagenes/Alejar.png" >
            </div>
        </header>

        <div class="cuadro" id="cuadrofinal">
    
            <div class="titulo">
                <h1 class="title">Test Ishihara</h1>
            </div>
            <div>

            <div>
                <img class="imagen_TEST" src="imagenes_Test/ishihara-image-18.jpg" src=""> 
            </div>
        
            <div class="titulo2">
                <h2  class="title2">¿Qué Ves?</h2>
            </div>
           
            <div class="opciones" id="opcionesContainer">
              <div id="opciondeuteranomalia" onclick="seleccionarOpcion(1)"> 2 </div>
                <div id="opcionNormal" onclick="seleccionarOpcion(0)"> 26 </div>
                <div id="opcionprotanomalia" onclick="seleccionarOpcion(-1)"> 6 </div>
            </div>
        </div>
        
        <script>
        var nombreEnJavaScript = "<?php echo $nombre; ?>";
    </script>
        <script src="JavaScript/Java_Opciones_Test_ishihara.js"></script>
        <script src="JavaScript/Java_Test_ishihara.js"></script>
        
    </div>
</body>
</html>
