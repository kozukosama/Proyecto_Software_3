<?php
$error = "";

if (isset($_POST['nombre'], $_POST['id'])) {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "daltonismo";

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $nombre = $conn->real_escape_string($_POST['nombre']);
    $dni = $conn->real_escape_string($_POST['id']);
    $resultadoTexto = $conn->real_escape_string($_POST['resultadoTexto']);
    
    $sql = "INSERT INTO `usuarios` (`RESULTADO`) VALUES ('$resultadoTexto')"; 

    
    $check_query = "SELECT * FROM `usuarios` WHERE `ID` = '$dni'";
    $check_result = $conn->query($check_query);
    
   
    if ($check_result->num_rows > 0) {
        $mensaje_error = "El usuario con el documento $dni ya realizó el test.";
      
    } else {
        $sql = "INSERT INTO `usuarios` (`ID`, `NOMBRE`, `RESULTADO`) VALUES ('$dni', '$nombre', '')";
    }

    if (!empty($sql)) { 
        if ($conn->query($sql) === TRUE) {
            header("Location: Test_ishihara.php" );
          
            session_start();
           $_SESSION['nombre'] = $nombre;
            exit();
        } else {
            $mensaje_error = "Error al ejecutar al guardar: " . $conn->error;
        }
    }
  
    $conn->close();

}

?>
